# 🤖 Web3 예측시장 무위험 차익거래 봇

[![Python](https://img.shields.io/badge/Python-3.11+-blue.svg)](https://www.python.org/)
[![License](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)
[![Docker](https://img.shields.io/badge/Docker-Ready-blue.svg)](https://www.docker.com/)

## 📋 목차
- [소개](#소개)
- [주요 기능](#주요-기능)
- [지원 플랫폼](#지원-플랫폼)
- [설치 방법](#설치-방법)
- [설정](#설정)
- [사용법](#사용법)
- [아키텍처](#아키텍처)
- [API 문서](#api-문서)
- [리스크 관리](#리스크-관리)
- [모니터링](#모니터링)
- [트러블슈팅](#트러블슈팅)
- [기여하기](#기여하기)

## 🌟 소개

Web3 예측시장 무위험 차익거래 봇은 여러 예측시장 플랫폼 간의 가격 차이를 실시간으로 모니터링하고, 수익 기회를 자동으로 포착하여 거래를 실행하는 자동화 시스템입니다.

### 핵심 개념

**예측시장 차익거래(Arbitrage)**란 동일한 사건에 대해 서로 다른 플랫폼에서 다르게 책정된 확률(가격)의 차이를 이용해 무위험 수익을 창출하는 전략입니다.

예시:
- Polymarket: "비트코인이 2025년 말까지 $100,000 도달" YES = 0.60 (60%)
- Kalshi: 동일 질문 NO = 0.45 (45%)
- 두 포지션 모두 진입 시 총 비용: $1.05
- 결과와 무관하게 $1.00 회수 보장 → 5% 무위험 수익

## ✨ 주요 기능

### 1. 실시간 시장 모니터링
- 3개 주요 예측시장 동시 스캔
- 초당 수십 개의 마켓 가격 추적
- WebSocket을 통한 실시간 업데이트

### 2. 자동 차익거래 탐지
- AI 기반 질문 유사도 매칭
- 다중 플랫폼 간 가격 비교
- 수익률 및 리스크 자동 계산

### 3. 스마트 주문 실행
- 최적 주문 크기 자동 계산
- 슬리피지 최소화 알고리즘
- 동시 주문 실행으로 리스크 최소화

### 4. 리스크 관리
- 포지션 크기 제한
- 총 노출도 관리
- VaR(Value at Risk) 계산
- 자동 손절매

### 5. 웹 대시보드
- 실시간 수익률 차트
- 활성 포지션 모니터링
- 리스크 지표 시각화
- 거래 로그 및 알림

## 🏛️ 지원 플랫폼

### 1. **Polymarket**
- 세계 최대 탈중앙화 예측시장
- Polygon 네트워크 기반
- USDC 사용
- 수수료: 0%

### 2. **Kalshi**
- 미국 CFTC 규제 플랫폼
- 법정화폐(USD) 직접 사용
- 높은 신뢰성
- 수수료: 거래액의 약 1%

### 3. **Manifold Markets**
- 커뮤니티 중심 예측시장
- 플레이 머니 + 실제 기부 가능
- 다양한 니치 마켓
- 수수료: 0%

## 🚀 설치 방법

### 요구사항
- Python 3.11 이상
- Node.js 16 이상 (대시보드용)
- Docker & Docker Compose (선택사항)
- 최소 4GB RAM
- 안정적인 인터넷 연결

### 옵션 1: 로컬 설치

```bash
# 1. 저장소 클론
git clone https://github.com/yourusername/prediction-arbitrage-bot.git
cd prediction-arbitrage-bot

# 2. 가상환경 생성 및 활성화
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# 3. 의존성 설치
pip install -r requirements.txt

# 4. 환경 변수 설정
cp .env.template .env
# .env 파일을 열어 API 키와 설정 입력

# 5. 봇 실행
python prediction-arbitrage-bot.py
```

### 옵션 2: Docker 사용

```bash
# 1. 저장소 클론
git clone https://github.com/yourusername/prediction-arbitrage-bot.git
cd prediction-arbitrage-bot

# 2. 환경 변수 설정
cp .env.template .env
# .env 파일 편집

# 3. Docker Compose로 실행
docker-compose up -d

# 4. 로그 확인
docker-compose logs -f arbitrage-bot
```

## ⚙️ 설정

### 필수 API 키 획득

#### Polymarket
1. MetaMask 지갑 생성
2. Polygon 네트워크에 USDC 준비
3. 개인키를 .env 파일에 입력

#### Kalshi
1. https://kalshi.com 계정 생성
2. KYC 인증 완료
3. 이메일/비밀번호를 .env 파일에 입력

#### Manifold Markets
1. https://manifold.markets 계정 생성
2. 설정에서 API 키 생성
3. API 키를 .env 파일에 입력

### 주요 설정 파라미터

```env
# 거래 파라미터
MIN_PROFIT_PERCENTAGE=1.0      # 최소 수익률 (%)
MAX_RISK_SCORE=0.3             # 최대 리스크 점수 (0-1)
MIN_CONFIDENCE_SCORE=0.7       # 최소 신뢰도 점수

# 리스크 관리
MAX_POSITION_SIZE=10000        # 단일 포지션 최대 크기 ($)
MAX_TOTAL_EXPOSURE=50000       # 총 최대 노출도 ($)
STOP_LOSS_PERCENTAGE=5.0       # 손절매 비율 (%)

# 모니터링
SCAN_INTERVAL=60               # 시장 스캔 간격 (초)
```

## 📊 사용법

### 기본 실행

```python
# 봇 시작
python prediction-arbitrage-bot.py

# 대시보드 접속
# 브라우저에서 http://localhost:8080 열기
```

### 프로그래매틱 사용

```python
from arbitrage_bot import ArbitrageEngine, PolymarketClient, KalshiClient

async def main():
    # 클라이언트 초기화
    poly = PolymarketClient(private_key)
    kalshi = KalshiClient(email, password)
    
    # 엔진 생성
    engine = ArbitrageEngine(poly, kalshi)
    
    # 차익거래 기회 탐색
    opportunities = await engine.find_opportunities()
    
    # 최상의 기회 실행
    if opportunities:
        best = opportunities[0]
        result = await engine.execute_arbitrage(best)
```

## 🏗️ 아키텍처

```
┌─────────────────────────────────────────────────────────┐
│                      Web Dashboard                       │
│                   (React + Chart.js)                     │
└────────────────────┬───────────────────────────────────┘
                     │ WebSocket
┌────────────────────┴───────────────────────────────────┐
│                    FastAPI Server                        │
│              (REST API + WebSocket Handler)              │
└────────────────────┬───────────────────────────────────┘
                     │
┌────────────────────┴───────────────────────────────────┐
│                  Arbitrage Engine                        │
│         (Opportunity Detection + Execution)              │
└──────┬─────────────┬─────────────┬─────────────────────┘
       │             │             │
┌──────┴──────┐ ┌───┴──────┐ ┌───┴──────┐
│ Polymarket  │ │  Kalshi   │ │ Manifold  │
│   Client    │ │  Client   │ │  Client   │
└─────────────┘ └───────────┘ └───────────┘
```

## 📡 API 문서

### REST API 엔드포인트

#### 봇 제어
- `POST /api/bot/start` - 봇 시작
- `POST /api/bot/stop` - 봇 정지
- `GET /api/bot/status` - 상태 조회

#### 데이터 조회
- `GET /api/opportunities` - 차익거래 기회 목록
- `GET /api/positions` - 활성 포지션 목록
- `GET /api/performance` - 성과 지표

#### 설정
- `GET /api/settings` - 현재 설정 조회
- `POST /api/settings` - 설정 업데이트

### WebSocket 이벤트

```javascript
// 연결
ws = new WebSocket('ws://localhost:8080/ws');

// 이벤트 수신
ws.onmessage = (event) => {
    const data = JSON.parse(event.data);
    // data.type: 'opportunity', 'position', 'log', 'status'
};
```

## 🛡️ 리스크 관리

### 1. 포지션 크기 관리
- Kelly Criterion 기반 최적 베팅 크기 계산
- 최대 포지션 크기 제한
- 분산 투자 강제

### 2. 해결 리스크 완화
- 질문 문구 유사도 검증
- 해결 소스 차이 확인
- 종료 시간 동기화

### 3. 유동성 리스크 관리
- 최소 유동성 요구사항
- 슬리피지 계산 및 제한
- 부분 체결 처리

### 4. 기술적 리스크
- API 장애 대응
- 네트워크 지연 처리
- 트랜잭션 실패 재시도

## 📈 모니터링

### Grafana 대시보드
- 실시간 수익률 추적
- 포지션별 P&L
- API 응답 시간
- 시스템 리소스 사용률

### 알림 설정
- Slack 통합
- Telegram 봇
- 이메일 알림
- Discord 웹훅

## 🔧 트러블슈팅

### 일반적인 문제 해결

#### 1. API 연결 실패
```bash
# API 키 확인
cat .env | grep API_KEY

# 네트워크 연결 테스트
curl https://api.polymarket.com/health
```

#### 2. 트랜잭션 실패
```bash
# 가스 가격 확인
python -c "from web3 import Web3; print(Web3.from_wei(w3.eth.gas_price, 'gwei'))"

# 잔액 확인
python check_balances.py
```

#### 3. 메모리 부족
```bash
# Docker 메모리 제한 증가
docker-compose down
# docker-compose.yml에서 mem_limit 수정
docker-compose up -d
```

### 로그 분석

```bash
# 실시간 로그 확인
tail -f logs/arbitrage_bot.log

# 에러 로그만 필터링
grep ERROR logs/arbitrage_bot.log

# 특정 날짜 로그 확인
grep "2024-01-15" logs/arbitrage_bot.log
```

## 🚨 중요 주의사항

### 법적 고려사항
- **지역 규제 확인**: 일부 지역에서는 예측시장 참여가 제한될 수 있습니다
- **세금 의무**: 수익에 대한 세금 신고 의무를 확인하세요
- **KYC/AML**: Kalshi 등 규제 플랫폼은 신원 확인이 필요합니다

### 기술적 위험
- **스마트 컨트랙트 리스크**: 버그나 해킹 가능성
- **네트워크 혼잡**: 높은 가스비로 인한 수익성 저하
- **API 제한**: Rate limiting으로 인한 기회 상실

### 시장 위험
- **해결 차이**: 플랫폼 간 다른 해결 기준
- **유동성 부족**: 큰 포지션 청산 어려움
- **가격 조작**: 일시적 가격 왜곡 가능성

## 📊 성과 분석

### 백테스팅

```python
# 과거 데이터로 전략 테스트
python backtest.py --start-date 2024-01-01 --end-date 2024-12-31

# 결과 분석
python analyze_results.py --input backtest_results.csv
```

### 주요 지표

- **Sharpe Ratio**: 위험 조정 수익률
- **Maximum Drawdown**: 최대 손실폭
- **Win Rate**: 성공적인 차익거래 비율
- **Average Profit**: 평균 수익률
- **Execution Time**: 평균 실행 시간

## 🔄 업데이트 및 유지보수

### 자동 업데이트

```bash
# 최신 버전 확인
git fetch origin
git status

# 안전한 업데이트
git stash
git pull origin main
git stash pop

# 의존성 업데이트
pip install --upgrade -r requirements.txt
```

### 데이터베이스 마이그레이션

```bash
# 마이그레이션 생성
alembic revision --autogenerate -m "Add new field"

# 마이그레이션 실행
alembic upgrade head

# 롤백
alembic downgrade -1
```

## 🤝 기여하기

### 기여 가이드라인

1. **Fork** 저장소
2. **Feature branch** 생성 (`git checkout -b feature/AmazingFeature`)
3. **변경사항 커밋** (`git commit -m 'Add some AmazingFeature'`)
4. **브랜치 푸시** (`git push origin feature/AmazingFeature`)
5. **Pull Request** 생성

### 코드 스타일

```bash
# 코드 포맷팅
black prediction-arbitrage-bot.py

# 린팅
pylint prediction-arbitrage-bot.py

# 타입 체크
mypy prediction-arbitrage-bot.py
```

### 테스트

```bash
# 단위 테스트 실행
pytest tests/

# 커버리지 확인
pytest --cov=arbitrage_bot tests/

# 통합 테스트
pytest tests/integration/
```

## 📚 추가 리소스

### 문서
- [Polymarket API 문서](https://docs.polymarket.com)
- [Kalshi API 문서](https://api.elections.kalshi.com/trade-api/docs)
- [Manifold API 문서](https://docs.manifold.markets)

### 커뮤니티
- Discord: [Join our server](https://discord.gg/prediction-arb)
- Telegram: [@PredictionArbBot](https://t.me/PredictionArbBot)
- Twitter: [@PredArbitrage](https://twitter.com/PredArbitrage)

### 튜토리얼
- [예측시장 차익거래 입문](docs/tutorial_kr.md)
- [고급 전략 가이드](docs/advanced_strategies.md)
- [리스크 관리 베스트 프랙티스](docs/risk_management.md)

## 🏆 성과 및 통계

### 2024년 실적 (예시)
- **총 거래 횟수**: 1,234회
- **평균 수익률**: 2.3%
- **성공률**: 89%
- **총 수익**: $45,678
- **최대 일일 수익**: $2,345

## 📝 라이선스

이 프로젝트는 MIT 라이선스 하에 배포됩니다. 자세한 내용은 [LICENSE](LICENSE) 파일을 참조하세요.

## ⚠️ 면책 조항

**이 소프트웨어는 교육 목적으로 제공됩니다. 실제 거래에 사용할 경우 발생하는 모든 손실에 대해 개발자는 책임지지 않습니다. 투자 결정을 내리기 전에 반드시 전문가와 상담하세요.**

### 위험 고지
- 예측시장은 변동성이 높고 예측 불가능합니다
- 기술적 오류로 인한 손실 가능성이 있습니다
- 규제 변경으로 서비스가 중단될 수 있습니다
- 과거 성과가 미래 수익을 보장하지 않습니다

## 🙏 감사의 말

이 프로젝트는 다음 오픈소스 프로젝트들의 도움으로 만들어졌습니다:
- Web3.py
- CCXT
- FastAPI
- React
- Chart.js

## 📞 문의

- **이메일**: contact@prediction-arbitrage.com
- **GitHub Issues**: [Create an issue](https://github.com/yourusername/prediction-arbitrage-bot/issues)
- **Discord**: [Join our community](https://discord.gg/prediction-arb)

---

**Made with ❤️ by the Prediction Arbitrage Team**

*Last updated: January 2025*
